
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'СИЗ','siz','2018-03-30 10:40:27','2018-03-30 10:40:27'),(2,'Инструменты','instrumenty','2018-03-30 10:40:27','2018-03-30 10:40:27'),(3,'Спецодежда','specodezhda','2018-03-30 10:40:27','2018-03-30 10:40:27'),(4,'Обувь','obuv','2018-03-30 10:40:27','2018-03-30 10:40:27'),(5,'Строительное оборудование','stroitelnoe-oborudovanie','2018-03-30 10:40:27','2018-03-30 10:40:27'),(6,'Тепловое оборудование','teplovoe-oborudovanie','2018-03-30 10:40:27','2018-03-30 10:40:27'),(7,'Грузоподъемное оборудование','gruzopodemnoe-oborudovanie','2018-03-30 10:40:27','2018-03-30 10:40:27'),(8,'Абразивный инструмент','abrazivnyy-instrument','2018-03-30 10:40:27','2018-03-30 10:40:27'),(9,'Монолитное строительство','monolitnoe-stroitelstvo','2018-03-30 10:40:27','2018-03-30 10:40:27'),(10,'Мебель','mebel','2018-03-30 10:40:27','2018-03-30 10:40:27'),(11,'Измерительный','izmeritelnyy','2018-03-30 10:40:27','2018-03-30 10:40:27');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_03_13_115053_create_categories_table',1),(4,'2018_03_13_132730_create_products_table',1),(5,'2018_03_13_132823_create_providers_table',1),(6,'2018_03_18_112426_add_avatar_colum_to_users',1),(7,'2018_03_18_205532_make_users_password',1),(8,'2018_03_19_090433_add_date_to_products',1),(9,'2018_03_19_104309_chang_data_to_date_products_table',1),(10,'2018_03_20_100304_add_field_providers',1),(11,'2018_03_21_103025_create_mproviders_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mproviders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mproviders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_con_p` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patronymic_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `office_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officedob_con_p` int(11) DEFAULT NULL,
  `email_con_p` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mproviders` WRITE;
/*!40000 ALTER TABLE `mproviders` DISABLE KEYS */;
/*!40000 ALTER TABLE `mproviders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prc` double(8,2) NOT NULL DEFAULT '0.00',
  `desc` text COLLATE utf8mb4_unicode_ci,
  `site` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (196,'Респиратор НРЗ ШБ-1 Л-200','30-Рес011',20.00,NULL,NULL,'40-af6809b0f196158a10c8b80b3537af74.jpg',NULL,NULL,0,NULL,'respirator-nrz-shb-1-l-200-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(197,'Респиратор НРЗ-1101 складной','30-Рес010',20.00,NULL,NULL,'40-1fe164c074c22139655a392c1a443518.jpg',NULL,1,0,NULL,'respirator-nrz-1101-skladnoy-1','2018-04-02 06:02:56','2018-04-02 06:04:39',NULL),(198,'Респиратор 3М 9101 VFlex™','30-Рес009',30.00,NULL,NULL,'40-5a127b7f6d3d5634c8eb0a169cc46bf0.jpg',NULL,NULL,0,NULL,'respirator-3m-9101-vflex-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(199,'Респиратор НРЗ-0113 с клапаном FFP3','30-Рес051',80.00,NULL,NULL,'40-15e8a92e8b2b8eb464b002b5a1c140e4.jpg',NULL,NULL,0,NULL,'respirator-nrz-0113-s-klapanom-ffp3-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(200,'Респиратор Исток-100','30-Рес008',30.00,NULL,NULL,'40-b3583ef40e65e3213dd0969aa7652109.jpg',NULL,NULL,0,NULL,'respirator-istok-100-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(201,'Респиратор 3М 8132','30-Рес050',140.00,NULL,NULL,'40-ff45e70b2948adf064ad60df551d326e.jpg',NULL,NULL,0,NULL,'respirator-3m-8132-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(202,'Респиратор У- 2К','30-Рес007',30.00,NULL,NULL,'40-65b5da83840468cfa39be9e412ed108b.jpg',NULL,NULL,0,NULL,'respirator-u-2k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(203,'Респиратор ЗМ 8322','30-Рес049',240.00,NULL,NULL,'40-76b250b6e7625d84f07f9032d2d99894.jpg',NULL,NULL,0,NULL,'respirator-zm-8322-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(204,'Респиратор Исток 1СК с клапаном','30-Рес006',30.00,NULL,NULL,'40-5f3ace7039b0c3b118d7fbf5df41a26b.jpg',NULL,NULL,0,NULL,'respirator-istok-1sk-s-klapanom-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(205,'Респиратор 3М 9913','30-Рес047',350.00,NULL,NULL,'40-e19cfaf4d303202144d8ed4ced65af93.jpg',NULL,NULL,0,NULL,'respirator-3m-9913-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(206,'Респиратор Исток 1ФК с клапаном','30-Рес005',30.00,NULL,NULL,'40-20e198973d37f42c6049c669fde5d5bd.jpg',NULL,NULL,0,NULL,'respirator-istok-1fk-s-klapanom-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(207,'Респиратор 3М 9925','30-Рес037',450.00,NULL,NULL,'40-8977f333cb7c312cf5f8b93c63dda011.jpg',NULL,NULL,0,NULL,'respirator-3m-9925-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(208,'Респиратор Исток 1С складной','30-Рес003',30.00,NULL,NULL,'40-915f9e36bd2bab8b2bf90b7aa65a403f.jpg',NULL,NULL,0,NULL,'respirator-istok-1s-skladnoy-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(209,'Респиратор 3М 9914','30-Рес036',330.00,NULL,NULL,'40-f0b24e4ce05a2beaa9547a42c7f0691a.jpg',NULL,NULL,0,NULL,'respirator-3m-9914-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(210,'Респиратор ЗМ 9926','30-Рес035',330.00,NULL,NULL,'40-43ba0596b60dc1d11e612bdaf2241414.jpg',NULL,NULL,0,NULL,'respirator-zm-9926-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(211,'Респиратор Исток 1Ф','30-Рес002',30.00,NULL,NULL,'40-356898102ed9fa7edbaa9121ec23381d.jpg',NULL,NULL,0,NULL,'respirator-istok-1f-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(212,'Респиратор ЗМ 9332','30-Рес034',330.00,NULL,NULL,'40-6e5df67a69b8dfb2e2b5ccb272f819d6.jpg',NULL,NULL,0,NULL,'respirator-zm-9332-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(213,'Респиратор Л-200','30-Рес001',20.00,NULL,NULL,'40-c6f3d7b80497a46e5af5c821fffd9061.jpg',NULL,NULL,0,NULL,'respirator-l-200-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(214,'Респиратор РУ-60М','30-Рес033',240.00,NULL,NULL,'40-a66ae5a455a17c1df8ec3d13bce2ec20.png',NULL,NULL,0,NULL,'respirator-ru-60m-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(215,'Пленка защитная 3М 6885','30-Пле001',90.00,NULL,NULL,'40-af1bd8af843ad80ad3f671d9c0a29b75.jpg',NULL,NULL,0,NULL,'plenka-zashchitnaya-3m-6885-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(216,'Респиратор 3М 9915','30-Рес032',270.00,NULL,NULL,'40-fe608eda5a2ac3e7c197bb839fffc7b7.jpg',NULL,NULL,0,NULL,'respirator-3m-9915-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(217,'Росток 1П-К','30-1010018',44.00,NULL,NULL,'rostok1pk.jpg',NULL,NULL,0,NULL,'rostok-1p-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(218,'Росток 1П','30-1010017',33.00,NULL,NULL,'rostok1p.jpg',NULL,NULL,0,NULL,'rostok-1p-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(219,'Респиратор Ф- 62Ш','30-Рес031',250.00,NULL,NULL,'40-aa9cd9b809c408ff00605632e82905f8.jpg',NULL,NULL,0,NULL,'respirator-f-62sh-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(220,'Росток 1Т-К','30-1010016',48.00,NULL,NULL,'rostok1tk.jpg',NULL,NULL,0,NULL,'rostok-1t-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(221,'Респиратор РПГ-67','30-Рес030',230.00,NULL,NULL,'40-0902cd3cd253a67f29d76396c3058d85.jpg',NULL,NULL,0,NULL,'respirator-rpg-67-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(222,'Росток 1Т','30-1010015',36.00,NULL,NULL,'rostok1t.jpg',NULL,NULL,0,NULL,'rostok-1t-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(223,'Респиратор 3М 8710','30-Рес029',220.00,NULL,NULL,'40-6cdb1eae65017aa13c3f077952d85bea.jpg',NULL,NULL,0,NULL,'respirator-3m-8710-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(224,'Росток 2','30-1010014',0.00,NULL,NULL,'rostok2.jpg',NULL,NULL,0,NULL,'rostok-2-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(225,'Респиратор Р- 2','30-Рес028',180.00,NULL,NULL,'40-720ff3387c9b346c41c76afcbb44d6e6.jpg',NULL,NULL,0,NULL,'respirator-r-2-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(226,'Росток 2Ф-К','30-1010013',48.00,NULL,NULL,'rostok2fk.jpg',NULL,NULL,0,NULL,'rostok-2f-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(227,'Респиратор 3М 9312','30-Рес027',180.00,NULL,NULL,'40-78658cb054051ef7e3c35c0f32c34eb9.jpg',NULL,NULL,0,NULL,'respirator-3m-9312-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(228,'Росток 2Ф','30-1010012',34.00,NULL,NULL,'rostok2f.jpg',NULL,NULL,0,NULL,'rostok-2f-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(229,'Респиратор 3М 9322','30-Рес026',180.00,NULL,NULL,'40-c5207042e31a29d8ef9cfd47396e962b.jpg',NULL,NULL,0,NULL,'respirator-3m-9322-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(230,'Росток 2П-К','30-1010011',31.00,NULL,NULL,'rostok2pk.jpg',NULL,NULL,0,NULL,'rostok-2p-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(231,'Респиратор 3М 9320','30-Рес025',170.00,NULL,NULL,'40-f5dd5e3b90a142fd319fdfc3e0e3777f.jpg',NULL,NULL,0,NULL,'respirator-3m-9320-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(232,'Росток 2П','30-1010010',26.00,NULL,NULL,'rostok2p.jpg',NULL,NULL,0,NULL,'rostok-2p-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(233,'Респиратор 3М 9310','30-Рес024',160.00,NULL,NULL,'40-98fa5f7646bebfef48302f8571670347.jpg',NULL,NULL,0,NULL,'respirator-3m-9310-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(234,'Росток 2Т-К','30-1010009',34.00,NULL,NULL,'rostok2tk.jpg',NULL,NULL,0,NULL,'rostok-2t-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(235,'Респиратор 3М 8122','30-Рес023',100.00,NULL,NULL,'40-9a8718fbfb11746e5f6cbd0e9373fdef.jpg',NULL,NULL,0,NULL,'respirator-3m-8122-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(236,'Росток 2Т','30-1010008',28.00,NULL,NULL,'rostok2t.jpg',NULL,NULL,0,NULL,'rostok-2t-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(237,'Респиратор 3М 8112','30-Рес022',90.00,NULL,NULL,'40-831432f134ca142df1de601bcc37aac8.jpg',NULL,NULL,0,NULL,'respirator-3m-8112-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(238,'Респиратор ЗМ 8102','30-Рес021',60.00,NULL,NULL,'40-d4880074682eb1311fd918bf38cc0375.jpg',NULL,NULL,0,NULL,'respirator-zm-8102-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(239,'Росток 3','30-1010007',0.00,NULL,NULL,'rostok3.jpg',NULL,NULL,0,NULL,'rostok-3-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(240,'Респиратор Исток 2СК с клапаном','30-Рес020',40.00,NULL,NULL,'40-0f823a76570d5a9bd6dfd1f4b735f4a5.jpg',NULL,NULL,0,NULL,'respirator-istok-2sk-s-klapanom-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(241,'Росток 3Ф-К','30-1010006',35.00,NULL,NULL,'rostok3fk.jpg',NULL,NULL,0,NULL,'rostok-3f-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(242,'Респиратор Исток 2ФК с клапаном','30-Рес019',40.00,NULL,NULL,'40-d53881da7d7b66229bfe534352f344e0.jpg',NULL,NULL,0,NULL,'respirator-istok-2fk-s-klapanom-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(243,'Росток 3Ф','30-1010005',25.00,NULL,NULL,'rostok3f.jpg',NULL,NULL,0,NULL,'rostok-3f-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(244,'Респиратор НРЗ-0112 с клапаном','30-Рес018',40.00,NULL,NULL,'40-728c3977536e7284347cc0eadeabf184.jpg',NULL,NULL,0,NULL,'respirator-nrz-0112-s-klapanom-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(245,'Росток 3П-К','30-1010004',24.00,NULL,NULL,'rostok3pk.jpg',NULL,NULL,0,NULL,'rostok-3p-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(246,'Росток 3П','30-1010003',21.00,NULL,NULL,'rostok3p.jpg',NULL,NULL,0,NULL,'rostok-3p-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(247,'Респиратор 3М 8101','30-Рес017',40.00,NULL,NULL,'40-cad197dcd3b344c577c196fc4663462d.jpg',NULL,NULL,0,NULL,'respirator-3m-8101-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(248,'Росток 3Т-К','30-1010002',26.00,NULL,NULL,'rostok3tk.jpg',NULL,NULL,0,NULL,'rostok-3t-k-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(249,'Респиратор 3М 9152 VFlex™','30-Рес016',30.00,NULL,NULL,'40-473b1a03ca9432b0bef5b4b05aaf8618.jpg',NULL,NULL,0,NULL,'respirator-3m-9152-vflex-1','2018-04-02 06:02:56','2018-04-02 06:02:56',NULL),(250,'Росток 3Т','30-1010001',22.00,NULL,NULL,'rostok3t.jpg',NULL,NULL,0,NULL,'rostok-3t-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(251,'Респиратор НРЗ-0102','30-Рес015',30.00,NULL,NULL,'40-450c697cef60fa0eeefc466cff93bcab.jpg',NULL,NULL,0,NULL,'respirator-nrz-0102-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(252,'Респиратор НРЗ-0111 с клапаном','30-Рес014',30.00,NULL,NULL,'40-a06e61d70466cfe5c9e8e074515725ba.jpg',NULL,NULL,0,NULL,'respirator-nrz-0111-s-klapanom-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(253,'Респиратор НРЗ-0101','30-Рес013',30.00,NULL,NULL,'40-d8c7b8d2089ea19f74c8c38367231b51.jpg',NULL,NULL,0,NULL,'respirator-nrz-0101-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(254,'Респиратор НРЗ-1102 складной','30-Рес012',20.00,NULL,NULL,'40-70d2305d9c25cdab090f3f4233cd8aa6.jpg',NULL,NULL,0,NULL,'respirator-nrz-1102-skladnoy-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(255,'Полумаска 3М 6200','30-Рес039',1620.00,NULL,NULL,'40-8b7f6469b10a0b3f3915b1c3025b82ab.jpg',NULL,NULL,0,NULL,'polumaska-3m-6200-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(256,'Полумаска 3М 6100','30-Рес038',1620.00,NULL,NULL,'40-13555e5119dd8f17a4c8ca4cd9a7779c.jpg',NULL,NULL,0,NULL,'polumaska-3m-6100-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(257,'Полумаска 3М 7503','30-Рес043',2740.00,NULL,NULL,'40-6e54baf5b80f379023373e84b33b767d.jpg',NULL,NULL,0,NULL,'polumaska-3m-7503-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(258,'Полумаска 3М 7502','30-Рес042',2740.00,NULL,NULL,'40-76b51b5bbd9448269febda2c405ee31f.jpg',NULL,NULL,0,NULL,'polumaska-3m-7502-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(259,'Полумаска 3М 7501','30-Рес041',2740.00,NULL,NULL,'40-5b670f23b0ea14e36cbe024d9992fee9.jpg',NULL,NULL,0,NULL,'polumaska-3m-7501-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL),(260,'Полумаска 3М 6300','30-Рес040',1620.00,NULL,NULL,'40-3b8eea35c00445240be6ad44c1abd8b6.jpg',NULL,NULL,0,NULL,'polumaska-3m-6300-1','2018-04-02 06:02:57','2018-04-02 06:02:57',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ean` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ur_address_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fz_address_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inn_provider` int(11) DEFAULT NULL,
  `kpp_provider` int(11) DEFAULT NULL,
  `rsch_provider` int(11) DEFAULT NULL,
  `krch_provider` int(11) DEFAULT NULL,
  `bancon_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bik_provider` int(11) DEFAULT NULL,
  `ogrn_provider` int(11) DEFAULT NULL,
  `telephone_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `director_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'Мир Инструмента',NULL,'http://instrument.ru/','mir-instrumenta','2018-04-02 07:17:32','2018-04-02 07:17:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'Мебель из Металла',NULL,'http://mebelizmetalla.ru/','mebel-iz-metalla','2018-04-02 07:18:23','2018-04-02 07:18:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'РЕМЭНЕРГОМАШ',NULL,'https://eme54.ru/','remenergomash','2018-04-02 07:56:20','2018-04-02 07:56:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stats` int(11) NOT NULL DEFAULT '0',
  `role` int(11) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

